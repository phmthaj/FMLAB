#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
CS224N 2025: Homework 3
utils.py: Utility Functions (đã chỉnh sửa an toàn)
"""

from typing import List
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import os
import sentencepiece as spm


def pad_sents(sents, pad_token):
    """Pad danh sách câu để tất cả có độ dài bằng nhau.
    Padding được thêm ở cuối mỗi câu.
    @param sents (list[list[str]]): danh sách các câu (list các từ)
    @param pad_token (str): token padding
    @returns sents_padded (list[list[str]]): danh sách câu đã pad
    """
    sents_padded = []
    max_len = max(len(s) for s in sents)
    for s in sents:
        num_pad = max_len - len(s)
        sents_padded.append(s + [pad_token] * num_pad)
    return sents_padded


def read_corpus(file_path, source, vocab_size=2500):
    """Đọc dữ liệu corpus. Tự động dùng SentencePiece nếu model tồn tại,
    nếu không thì fallback sang split() thường.
    @param file_path (str): đường dẫn đến file dữ liệu
    @param source (str): "src" hoặc "tgt"
    @param vocab_size (int): kích thước vocab (không dùng nếu đã có model)
    """
    data = []

    # Tìm model trong cùng thư mục dữ liệu (vd: zh_en_data/src.model)
    base_dir = os.path.dirname(file_path)
    model_path = os.path.join(base_dir, f"{source}.model")

    sp = None
    if os.path.exists(model_path):
        sp = spm.SentencePieceProcessor()
        sp.load(model_path)
        print(f"[INFO] Loaded SentencePiece model from {model_path}")
    else:
        print(f"[WARN] Không tìm thấy {model_path}, fallback sang split() thường.")

    with open(file_path, 'r', encoding='utf8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue  # bỏ dòng trống

            if sp:
                tokens = sp.encode_as_pieces(line)
            else:
                tokens = line.split()

            # Thêm <s> và </s> cho câu target
            if source == 'tgt':
                tokens = ['<s>'] + tokens + ['</s>']

            data.append(tokens)

    if len(data) == 0:
        raise ValueError(f"⚠️ File {file_path} không có câu hợp lệ — kiểm tra lại dữ liệu!")

    return data


def autograder_read_corpus(file_path, source):
    """Phiên bản cho autograder — không dùng SentencePiece."""
    import nltk
    nltk.download('punkt', quiet=True)
    data = []
    with open(file_path, encoding='utf8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            sent = nltk.word_tokenize(line)
            if source == 'tgt':
                sent = ['<s>'] + sent + ['</s>']
            data.append(sent)
    return data


def batch_iter(data, batch_size, shuffle=False):
    """Yield các batch của (src_sent, tgt_sent), sắp xếp theo độ dài giảm dần."""
    batch_num = math.ceil(len(data) / batch_size)
    index_array = list(range(len(data)))

    if shuffle:
        np.random.shuffle(index_array)

    for i in range(batch_num):
        indices = index_array[i * batch_size: (i + 1) * batch_size]
        examples = [data[idx] for idx in indices]

        # Sắp xếp theo độ dài câu source giảm dần
        examples = sorted(examples, key=lambda e: len(e[0]), reverse=True)
        src_sents = [e[0] for e in examples]
        tgt_sents = [e[1] for e in examples]

        yield src_sents, tgt_sents
