#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Model Embeddings for NMT (Source and Target)
"""

import torch
import torch.nn as nn

class ModelEmbeddings(nn.Module):
    """
    Class that converts words to embeddings for both source and target languages.
    """

    def __init__(self, embed_size: int, vocab):
        """ Initialize the Embedding layers.

        @param embed_size (int): Embedding size
        @param vocab (Vocab): Vocab object containing VocabEntry for src and tgt
        """
        super(ModelEmbeddings, self).__init__()

        self.embed_size = embed_size
        self.vocab = vocab

        pad_token_src = vocab.src['<pad>']
        pad_token_tgt = vocab.tgt['<pad>']

        # ✅ Source and Target Embedding layers
        self.source = nn.Embedding(len(vocab.src), embed_size, padding_idx=pad_token_src)
        self.target = nn.Embedding(len(vocab.tgt), embed_size, padding_idx=pad_token_tgt)

        # Optional: embedding dropout
        self.dropout = nn.Dropout(0.3)

    def forward(self, x: torch.Tensor, target: bool = False) -> torch.Tensor:
        """ Look up embeddings for x.

        @param x (Tensor): Tensor of word indices
        @param target (bool): whether this is target side (default=False)
        @returns (Tensor): Embeddings (seq_len, batch_size, embed_size)
        """
        if target:
            emb = self.target(x)
        else:
            emb = self.source(x)
        return self.dropout(emb)
