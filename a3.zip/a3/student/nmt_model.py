#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from collections import namedtuple
import sys
from typing import List, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import pad_packed_sequence, pack_padded_sequence
from model_embeddings import ModelEmbeddings

Hypothesis = namedtuple('Hypothesis', ['value', 'score'])

class NMT(nn.Module):
    def __init__(self, embed_size, hidden_size, vocab, dropout_rate=0.2):
        super().__init__()
        self.model_embeddings = ModelEmbeddings(embed_size, vocab)
        self.hidden_size = hidden_size
        self.dropout_rate = dropout_rate
        self.vocab = vocab

        self.post_embed_cnn = nn.Conv1d(embed_size, embed_size, kernel_size=2, padding=1)
        self.encoder = nn.LSTM(embed_size, hidden_size, bidirectional=True, bias=True)
        self.decoder = nn.LSTMCell(embed_size + hidden_size, hidden_size, bias=True)

        self.h_projection = nn.Linear(2 * hidden_size, hidden_size, bias=False)
        self.c_projection = nn.Linear(2 * hidden_size, hidden_size, bias=False)
        self.att_projection = nn.Linear(2 * hidden_size, hidden_size, bias=False)
        self.combined_output_projection = nn.Linear(3 * hidden_size, hidden_size, bias=False)
        self.target_vocab_projection = nn.Linear(hidden_size, len(vocab.tgt), bias=False)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, source: List[List[str]], target: List[List[str]]) -> torch.Tensor:
        source_lengths = [len(s) for s in source]
        source_padded = self.vocab.src.to_input_tensor(source, device=self.device)
        target_padded = self.vocab.tgt.to_input_tensor(target, device=self.device)

        enc_hiddens, dec_init_state = self.encode(source_padded, source_lengths)
        enc_masks = self.generate_sent_masks(enc_hiddens, source_lengths)
        combined_outputs = self.decode(enc_hiddens, enc_masks, dec_init_state, target_padded)
        P = F.log_softmax(self.target_vocab_projection(combined_outputs), dim=-1)

        target_masks = (target_padded != self.vocab.tgt['<pad>']).float()
        target_gold_words_log_prob = torch.gather(
            P, index=target_padded[1:].unsqueeze(-1), dim=-1
        ).squeeze(-1) * target_masks[1:]
        return target_gold_words_log_prob.sum(dim=0)

    def encode(self, source_padded: torch.Tensor, source_lengths: List[int]) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
  
        X = self.model_embeddings.source(source_padded)   # (src_len, batch, embed_size)

        packed_src = pack_padded_sequence(X, source_lengths, enforce_sorted=False)
        enc_hiddens, (last_hidden, last_cell) = self.encoder(packed_src)
        enc_hiddens, _ = pad_packed_sequence(enc_hiddens)     # (src_len, batch, 2*hidden)
        enc_hiddens = enc_hiddens.permute(1, 0, 2)            # (batch, src_len, 2*hidden)

        last_hidden_cat = torch.cat((last_hidden[0], last_hidden[1]), dim=1)  # (batch, 2*hidden)
        last_cell_cat   = torch.cat((last_cell[0], last_cell[1]), dim=1)      # (batch, 2*hidden)
        init_h = self.h_projection(last_hidden_cat)                           # (batch, hidden)
        init_c = self.c_projection(last_cell_cat)                             # (batch, hidden)
        return enc_hiddens, (init_h, init_c)


    def decode(self, enc_hiddens: torch.Tensor, enc_masks: torch.Tensor,
               dec_init_state: Tuple[torch.Tensor, torch.Tensor], target_padded: torch.Tensor) -> torch.Tensor:
        target_padded = target_padded[:-1]
        dec_state = dec_init_state
        bsz = enc_hiddens.size(0)
        o_prev = torch.zeros(bsz, self.hidden_size, device=self.device)
        outputs = []

        enc_hiddens_proj = self.att_projection(enc_hiddens)            # (b, src_len, h)
        Y = self.model_embeddings.target(target_padded)                 # (tgt_len, b, e)

        for Y_t in torch.split(Y, 1):
            Y_t = Y_t.squeeze(0)                                       # (b, e)
            Ybar_t = torch.cat([Y_t, o_prev], dim=1)                   # (b, e+h)
            dec_state, o_t, _ = self.step(Ybar_t, dec_state, enc_hiddens, enc_hiddens_proj, enc_masks)
            outputs.append(o_t)
            o_prev = o_t

        return torch.stack(outputs)                                     # (tgt_len, b, h)

    def step(self, Ybar_t: torch.Tensor,
             dec_state: Tuple[torch.Tensor, torch.Tensor],
             enc_hiddens: torch.Tensor,
             enc_hiddens_proj: torch.Tensor,
             enc_masks: torch.Tensor) -> Tuple[Tuple, torch.Tensor, torch.Tensor]:
        dec_state = self.decoder(Ybar_t, dec_state)
        dec_hidden, dec_cell = dec_state                                # (b, h)

        e_t = torch.bmm(enc_hiddens_proj, dec_hidden.unsqueeze(2)).squeeze(2)  # (b, src_len)
        if enc_masks is not None:
            e_t.data.masked_fill_(enc_masks.bool(), -float('inf'))
        alpha_t = F.softmax(e_t, dim=1)                                 # (b, src_len)
        a_t = torch.bmm(alpha_t.unsqueeze(1), enc_hiddens).squeeze(1)   # (b, 2h)

        U_t = torch.cat((dec_hidden, a_t), dim=1)                       # (b, 3h)
        V_t = self.combined_output_projection(U_t)                      # (b, h)
        O_t = self.dropout(torch.tanh(V_t))                             # (b, h)
        return dec_state, O_t, e_t

    def generate_sent_masks(self, enc_hiddens: torch.Tensor, source_lengths: List[int]) -> torch.Tensor:
        enc_masks = torch.zeros(enc_hiddens.size(0), enc_hiddens.size(1), dtype=torch.float)
        for i, L in enumerate(source_lengths):
            enc_masks[i, L:] = 1
        return enc_masks.to(self.device)

    def beam_search(self, src_sent: List[str], beam_size: int = 5, max_decoding_time_step: int = 70) -> List[Hypothesis]:
        src_sents_var = self.vocab.src.to_input_tensor([src_sent], self.device)
        src_encodings, dec_init_vec = self.encode(src_sents_var, [len(src_sent)])
        src_encodings_att_linear = self.att_projection(src_encodings)

        h_tm1 = dec_init_vec
        att_tm1 = torch.zeros(1, self.hidden_size, device=self.device)
        eos_id = self.vocab.tgt['</s>']

        hyps = [['<s>']]
        hyp_scores = torch.zeros(len(hyps), dtype=torch.float, device=self.device)
        completed = []
        t = 0
        while len(completed) < beam_size and t < max_decoding_time_step:
            t += 1
            H = len(hyps)
            exp_enc = src_encodings.expand(H, src_encodings.size(1), src_encodings.size(2))
            exp_enc_att = src_encodings_att_linear.expand(H, src_encodings_att_linear.size(1), src_encodings_att_linear.size(2))
            y_tm1 = torch.tensor([self.vocab.tgt[h[-1]] for h in hyps], dtype=torch.long, device=self.device)
            y_emb = self.model_embeddings.target(y_tm1)
            x = torch.cat([y_emb, att_tm1], dim=-1)
            (h_t, c_t), att_t, _ = self.step(x, h_tm1, exp_enc, exp_enc_att, enc_masks=None)
            log_p_t = F.log_softmax(self.target_vocab_projection(att_t), dim=-1)

            live = beam_size - len(completed)
            cont_scores = (hyp_scores.unsqueeze(1).expand_as(log_p_t) + log_p_t).view(-1)
            top_scores, top_pos = torch.topk(cont_scores, k=live)
            prev_ids = torch.div(top_pos, len(self.vocab.tgt), rounding_mode='floor')
            word_ids = top_pos % len(self.vocab.tgt)

            new_hyps, live_ids, new_scores = [], [], []
            for pid, wid, sc in zip(prev_ids, word_ids, top_scores):
                pid, wid, sc = pid.item(), wid.item(), sc.item()
                w = self.vocab.tgt.id2word[wid]
                cand = hyps[pid] + [w]
                if w == '</s>':
                    completed.append(Hypothesis(value=cand[1:-1], score=sc))
                else:
                    new_hyps.append(cand); live_ids.append(pid); new_scores.append(sc)

            if len(completed) == beam_size: break
            live_ids = torch.tensor(live_ids, dtype=torch.long, device=self.device)
            h_tm1 = (h_t[live_ids], c_t[live_ids])
            att_tm1 = att_t[live_ids]
            hyps = new_hyps
            hyp_scores = torch.tensor(new_scores, dtype=torch.float, device=self.device)

        if len(completed) == 0:
            completed.append(Hypothesis(value=hyps[0][1:], score=hyp_scores[0].item()))
        completed.sort(key=lambda h: h.score, reverse=True)
        return completed

    @property
    def device(self) -> torch.device:
        # LẤY THIẾT BỊ TỪ THAM SỐ BẤT KỲ CỦA MẠNG (an toàn dù bạn chưa gọi embedding)
        return next(self.parameters()).device

    @staticmethod
    def load(model_path: str):
        params = torch.load(model_path, map_location=lambda storage, loc: storage)
        args = params['args']
        model = NMT(vocab=params['vocab'], **args)
        model.load_state_dict(params['state_dict'])
        return model

    def save(self, path: str):
        print(f'save model parameters to [{path}]', file=sys.stderr)
        params = {
            'args': dict(embed_size=self.model_embeddings.embed_size,
                         hidden_size=self.hidden_size,
                         dropout_rate=self.dropout_rate),
            'vocab': self.vocab,
            'state_dict': self.state_dict()
        }
        torch.save(params, path)
